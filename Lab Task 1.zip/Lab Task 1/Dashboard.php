<html>
   <h1>Welcome  <?php echo $_COOKIE["username"];?></h1>
</html>