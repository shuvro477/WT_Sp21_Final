<html>
 <head><title>View Details</title>
    <style>
	    #header{
			height:25px;
			background-color:black;
			position:fixed;
			width:100%;
			top:0;
			left:0;
			color:white
		}
		
	    #p1div{
			border:1px solid black;
			margin:auto;
			width:50%;
			border-radius:10px;
			padding-left:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		
	</style>
 </head>
 <body style="background-color:rgb(151, 117, 250);">
    <div id="header"></div><br>
    <H1 style="text-align:center;"> Need Math Tutor for Class 9 Student - 3Days/Week </H1>
	<p style="text-align:center;"><b>ID:1005</b></p><br>
	<div id="p1div" style="background-color: white;">
        <p>Posted Date: Jan 04,2021 </p>
        <ul type="square">                               
	        <li><b>Subjects:</b><br> Math</li><br>
			<li><b>No of Student: </b><br> 1</li><br>
			<li><b>Student Gender: </b><br> Female</li><br>
			<li><b>Preferred Tutor: </b><br> Any</li><br>
			<li><b>Tutoring Days: </b><br> 3Days/Week</li><br>
	        <li><b>Salary: </b><br> 4000BDT</li><br>
			<li><b>Tutoring Time: </b><br> 6:30PM</li><br>
			<li><b>Location: </b><br> Esa Khan Road, Narayanganj </li><br> 
			<li><b>Other Requirements: </b><br> Interested tutors are requested to contact.</li><br>
		<table><tr>
		     <td colspan="2" align="right"><input type="submit" value="Apply" name="Apply"></td>
		</tr></table>
	</div><br>
  
 </body>
</html>