<html> 
  
    <body style="background-color:powderblue;">
     	<fieldset style="width:800px;border:solid 2px" >
			<legend> <h1> Tuition Information </h1></legend>
			 <span> <b>Name</b>  Abdullah Al Noman   <br><b>Tuition-ID:</b>#W-0976 <br><b>  Qualification:</b> BBA  </span> <br> 
			 <span> <b>Areas:</b>Banani, Banani DOHS </span><br>
             <span> <b>Teaching:</b> All, Bangla, English, General Math, General Science, Islamic Studies</span><br>
             <span> <b>Experience:</b> 2 years.</span> <br> 
             <span> <b>preferred subjects :</b> All, Bangla, Biology, Chemistry, English, General Math, General Science, Higher Maths, Physics</span><br>
			 <span> <b> preferred medium: </b> English </span> <br> 
             <span> <b>Experience:</b> 2 years.</span> <br> 
			 <span> <b> Expected minimum salary:</b> 4000Tk/month </span> <br> 
			 <span> <b>Current Status: </b> Available </span> <br> 
			 <span> <b> preferred time: </b> After Mgrib   <span>  <br> 
			 <span> <b> Days per week:  </b> 5days </span> <br> 
			 </body>
			 </html> 