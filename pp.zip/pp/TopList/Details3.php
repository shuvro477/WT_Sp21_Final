<html> 
  
    <body style="background-color:purple;">
     	<fieldset style="width:800px;border:solid 2px" >
			<legend> <h1> Tuition Information </h1></legend>
			 <span> <b>Name</b> Afrina Mim  <br><b>Tuition-ID:</b>#G-03476 <br><b>  Qualification:</b>KUET-cse engineer   </span> <br> 
			 <span> <b>Areas:</b>Bashundara residential area  </span><br>
             <span> <b>Teaching:</b> Physics, Chemistry , biology </span><br>
             <span> <b>Experience:</b> 4 years.</span> <br> 
             <span> <b>preferred subjects :</b> Chemistry, English, General Math,Higher Maths, Physics</span><br>
			 <span> <b> preferred medium: </b> English </span> <br> 
             <span> <b>Experience:</b> 4 years.</span> <br> 
			 <span> <b> Expected minimum salary:</b> 8000Tk/month </span> <br> 
			 <span> <b>Current Status: </b> Available </span> <br> 
			 <span> <b> preferred time: </b> Evening    <span>  <br> 
			 <span> <b> Days per week:  </b> 3 days </span> <br> 
			 </body>
			 </html> 