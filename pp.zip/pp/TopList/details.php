<html> 
  
    <body style="background-color:powderblue;">
     	<fieldset style="width:800px;border:solid 2px" >
			<legend> <h1> Tuition Information </h1></legend>
			 <span> <b>name:</b>   Evan Sarwar  <br> <b>Tuition-ID:</b>#H-0034 <br><b>  Qualification:</b> BSC in CSE  </span> <br> 
			 <span> <b>preferred Areas:</b> Azimpur, Bangla Motor, Dhaka University Area, Dhanmondi, Easkaton, Elephant Road, Farmgate,<br>
			 Green Road, Hatirjheel, Indira Road, Kalabagan, Moghbazar, Monipuripara, New Eskaton Road,<br>
			 New market, Panthapath, Shabagh, Sukrabad, Tejkunipara, Zigatola</span><br>
             <span> <b>preferred subjects :</b> All, Bangla, Biology, Chemistry, English, General Math, General Science, Higher Maths, Physics</span><br>
			 <span> <b> preferred medium: </b> Bangla </span> <br> 
             <span> <b>Experience:</b> 2 years.</span> <br> 
			 <span> <b> Expected minimum salary:</b> 5000Tk/month </span> <br> 
			 <span> <b>Current Status: </b> Available </span> <br> 
			 <span> <b> preferred time: </b> Evening <span>  <br> 
			 <span> <b> Days per week:  </b> 3/4 days </span> <br> 
			 </body>
			 </html> 