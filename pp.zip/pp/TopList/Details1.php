<html> 
  
    <body style="background-color:powderblue;">
     	<fieldset style="width:800px;border:solid 2px" >
			<legend> <h1> Tuition Information </h1></legend>
			 <span> <b>Name</b> Tasnuva akter Tonni  <br><b>Tuition-ID:</b>#F-0123 <br><b>  Qualification:</b> Undergrad student   </span> <br> 
			 <span> <b>Areas:</b> Cantonment, Cantonment (Matikata), Ibrahimpur, Kafrul, Kuril, Mirpur -10, Mirpur -14</span><br>
             <span> <b>Teaching:</b> Biology, Chemistry, Higher Maths, Physics</span><br>
             <span> <b>Experience:</b> 3 years.</span>
             <span> <b>preferred subjects :</b> All, Bangla, Biology, Chemistry, English, General Math, General Science, Higher Maths, Physics</span><br>
			 <span> <b> preferred medium: </b> English </span> <br> 
             <span> <b>Experience:</b> 3 years.</span> <br> 
			 <span> <b> Expected minimum salary:</b> 6000Tk/month </span> <br> 
			 <span> <b>Current Status: </b> Available </span> <br> 
			 <span> <b> preferred time: </b> Morning  <span>  <br> 
			 <span> <b> Days per week:  </b> 3 days </span> <br> 
			 </body>
			 </html> 