<html>
 <head><title>View Details</title>
    <style>
	    #header{
			height:25px;
			background-color:black;
			position:fixed;
			width:100%;
			top:0;
			left:0;
			color:white
		}
		
	    #p1div{
			border:1px solid black;
			margin:auto;
			width:50%;
			border-radius:10px;
			padding-left:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		
	</style>
 </head>
 <body style="background-color:rgb(151, 117, 250);">
    <div id="header"></div><br>
    <H1 style="text-align:center;"> Need Bangla Medium Tutor for Class 2 Student - 5Days/Week </H1>
	<p style="text-align:center;"><b>ID:1001</b></p><br>
	<div id="p1div" style="background-color: white;">
        <p>Posted Date: Mar 12,2021 </p>
        <ul type="square">                               
	        <li><b>Subjects:</b><br> All</li><br>
			<li><b>No of Student: </b><br> 1</li><br>
			<li><b>Student Gender: </b><br> Male</li><br>
			<li><b>Preferred Tutor: </b><br> Male & Female</li><br>
			<li><b>Tutoring Days: </b><br> 5Days/Week</li><br>
	        <li><b>Salary: </b><br> 3000BDT</li><br>
			<li><b>Tutoring Time: </b><br> 6:00PM</li><br>
			<li><b>Location: </b><br> Mirpur 13, Dhaka </li><br> 
			<li><b>Other Requirements: </b><br> Interested tutors are requested to contact.</li><br>
		<table><tr>
		     <td colspan="2" align="right"><input type="submit" value="Apply" name="Apply"></td>
		</tr></table>
	</div><br>
  
 </body>
</html>