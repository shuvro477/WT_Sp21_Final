<?php
session_start();
?>
<html>
	<head>
		
		<link rel="stylesheet" href="style.css">
	</head>
	<body>

		<table border="0px" width="100%" cellpadding="0px" cellspacing="0px" bgcolor="#f1f1f1">
			<tr>
				<td width="20%" height="60px" align="center"><font size="10px" color="dodgerblue"><b><?php echo $_SESSION["uname"]; ?> </b></font></td>
			</tr>
			<tr>
				
			</tr>
		</table>
		
		<table border="0px" width="100%" height="60px" cellpadding="0px" cellspacing="0px">
			<tr>
				<td bgcolor="#AFDED3">
				&emsp; &emsp;
					<a href="Profile.php">Profile</a>
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
					<a href="ChangePassword.php">Change Password</a> 
					&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;				
				</td>
				<td bgcolor="#AFDED3">
					<a href="PostTution.php">Post Tution</a>
				</td>
				<td bgcolor="#AFDED3">
					<a href="SearchTutor.php">Search Tutor</a>
				</td>
				<td height="20px" bgcolor="grey"align="right">
					
					<a href="../tution_station.php"><font color="white"><img align=middle width="35px" height="38px" src="pictures/logOut.png"></font></a>	
				</td>
			</tr>
		</table>
		
	</body>
</html>