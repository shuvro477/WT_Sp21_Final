<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>

<?php
	include_once("Header.php");
?>

<script type="text/javascript">

	
	function Title(){
	var un=document.frm.title.value; //document=DOM object
	if(un.length<5){
		document.frm.title.style.color="red";
		//document.frm.cName.style.border="1px solid red";
		document.getElementById("msgT").innerHTML="Provide Valid Title";
	}
	else{
		document.frm.title.style.color="black";
		document.getElementById("msgT").innerHTML="🗸";
	}
	}

	function InTitle(){
	var un=document.frm.inst.value; //document=DOM object
	if(un.length<5){
		document.frm.inst.style.color="red";
		//document.frm.cName.style.border="1px solid red";
		document.getElementById("msgIN").innerHTML="Provide Institution info";
	}
	else{
		document.frm.inst.style.color="black";
		document.getElementById("msgIN").innerHTML="🗸";
	}
	}

	function Name(){
	var un=document.frm.cName.value; //document=DOM object
	if(un.length<5){
		document.frm.cName.style.color="red";
		document.frm.cName.style.border="1px solid red";
		document.getElementById("msg").innerHTML="...";
	}
	else{
		document.frm.cName.style.color="green";
		document.getElementById("msg").innerHTML="🗸";
	}
	}
	
	function Gender(){
	var un=document.frm.gender.value; //document=DOM object
	if(un.length<0){
		document.frm.gender.style.color="red";
		//document.frm.gender.style.border="1px solid red";
		document.getElementById("msgG").innerHTML="Provide Gender";
	}
	else{
		document.frm.gender.style.color="black";
		document.getElementById("msgG").innerHTML="Info Taken 🗸";
	}
	}
	function Medium(){
	var un=document.frm.medium.value; //document=DOM object
	if(un.length<0){
		document.frm.medium.style.color="red";
		//document.frm.medium.style.border="1px solid red";
		document.getElementById("msgMd").innerHTML="Provide Medium";
	}
	else{
		document.frm.medium.style.color="black";
		document.getElementById("msgMd").innerHTML="Medium Taken 🗸";
	}
	}
	
	function Phone(){
	var un=document.frm.phn.value; //document=DOM object
	if(un.length<11 || un.length>11){
		document.frm.phn.style.color="red";
		//document.frm.phn.style.border="1px solid red";
		document.getElementById("msg4").innerHTML="Typing...";
	}
	else{
		document.frm.phn.style.color="black";
		document.getElementById("msg4").innerHTML="Info Taken!";
	}
	}

	
	function Salary(){
	var un=document.frm.sal.value; //document=DOM object
	if(un.length<3){
		document.frm.sal.style.color="red";
		//document.frm.phn.style.border="1px solid red";
		document.getElementById("msgS").innerHTML="Typing...";
	}
	else{
		document.frm.sal.style.color="black";
		document.getElementById("msgS").innerHTML="Info Taken 🗸";
	}
	}
	
	function Address(){
	var un=document.frm.address.value; //document=DOM object
	if(un.length<4){
		document.frm.address.style.color="red";
		//document.frm.address.style.border="1px solid red";
		document.getElementById("msg5").innerHTML="invalid info 🗸";
	}
	else{
		document.frm.address.style.color="black";
		document.getElementById("msg5").innerHTML="Info Taken 🗸";
	}
	}
	function emailV(){
	var un=document.frm.email.value; //document=DOM object
	if(un.indexOf("@")<1){
		document.frm.email.style.color="red";
		//document.frm.address.style.border="1px solid red";
		document.getElementById("msg9").innerHTML="invalid email info";
	}
	else{
		document.frm.email.style.color="black";
		document.getElementById("msg9").innerHTML="Info Taken 🗸";
	}
	}

	function Info(){
	var un=document.frm.info.value; //document=DOM object
	if(un.length<3){
		document.frm.info.style.color="red";
		//document.frm.phn.style.border="1px solid red";
		document.getElementById("msgInfo").innerHTML="Typing...";
	}
	else{
		document.frm.info.style.color="black";
		document.getElementById("msgInfo").innerHTML="Info Taken 🗸";
	}
	}
	//alert(un);


</script>

<form action="PostTutionSubmit.php" name="frm" id="frm" method="post"> <pre><!--  -->
		<Title>
		Post Tution 
		</title>				
		
		
		<table border="1px" align="center">
		<tr>
		<td align="center">
			</br>
			
			Title: &emsp;&emsp;
			<input onkeyup="Title()" type="text" class="form-control" name="title" id="txt" > <span id="msgT"></span> <br/> </br>
			Name: &emsp;&emsp;
			<input onkeyup="Name()" type="text" class="form-control" name="cName" id="txt" > <span id="msg"></span> <br/> </br>
			Institution: &emsp;&emsp;
			<input onkeyup="InTitle()" type="text" class="form-control" name="inst" id="txt" > <span id="msgIN"></span> <br/> </br>
						
			Gender: <br/> 
			<input onkeyup="Gender()" type="radio" name="gender" value="male" id="gn"> Male &emsp;&emsp;&emsp;
			<input onkeyup="Gender()" type="radio" name="gender" value="female" id="gn"> Female<br> 
			<span id="msgG"></span> <br/>

			Medium: <br/> 
			<input onkeyup="Medium()" type="radio" name="medium" value="Bangla" id="gn"> Bangla &emsp;&emsp;&emsp;
			<input onkeyup="Medium()" type="radio" name="medium" value="English" id="gn"> English<br> 
			<span id="msgM"></span> <br/>

			<label for="class">Class</label>
  			<select name="class" id="class" class="form-control">
    			<optgroup label="Primary School">
      				<option value="1">1</option>
      				<option value="2">2</option>
      				<option value="3">3</option>
      				<option value="4">4</option>
      				<option value="5">5</option>
    			</optgroup>
				<optgroup label="High School">
      				<option value="6">6</option>
      				<option value="7">7</option>
      				<option value="8">8</option>
      				<option value="9">9</option>
      				<option value="10">10</option>
    			</optgroup>
    			<optgroup label="College">
      				<option value="1st Year">1st Year</option>
      				<option value="2nd Year">2nd Year</option>
    			</optgroup>
  			</select>

  			<br/> </br> 

  			<label for="dc">Days Per Week : </label>

			<select name="dc" id="dc">
  				<option value="1">1</option>
      			<option value="2">2</option>
      			<option value="3">3</option>
      			<option value="4">4</option>
      			<option value="5">5</option>
      			<option value="6">6</option>
      			<option value="7">7</option>
			</select>
			<br/> </br> 			
			
			Salary: 
			<input onkeyup="Salary()"  type="text" name="sal" id="pn" class="form-control"> <br/> <span id="msgS"></span> <br/>

			Phone No.: 
			<input onkeyup="Phone()"  type="text" name="phn" id="pn" class="form-control"> <br/> <span id="msg4"></span> <br/>
			
			Address: &emsp;
			<input onkeyup="Address()" type="text" name="address" id="thikana" class="form-control"> <br/> <span id="msg5"></span> <br/>

			Email: &emsp;&emsp;&emsp;
			<input onkeyup="emailV()" type="text" name="email" id="aaa" class="form-control"> <br/> <span id="msg9"> </span> <br/>

			info: &emsp;&emsp;
			<input onkeyup="Info()" type="text" name="info" id="txt" class="form-control"> <span id="msgInfo"></span> <br/> </br>
			
			<p> <input type="submit" onclick="return validate()" name="sbt" value="Post" class="btn btn-primary"/><br> </p>
			<span id="msg11"></span>
			</br>
			</td>
		</tr>
			</table>
			

	</pre>
</form>

<script type="text/javascript">
	function validate(){

	//console.log(serialize(document.forms[0]));
	var flag=true;
	
	var Cn=document.frm.cName.value;
	var tn=document.frm.title.value;
	var ins=document.frm.inst.value;
	var gender=document.frm.gender.value;
	var medium=document.frm.medium.value;
	var sal=document.frm.sal.value;
	var dc=document.frm.dc.value;
	var phn=document.frm.phn.value;
	var info=document.frm.info.value;
	var ads=document.frm.address.value;
	var email=document.frm.email.value;

	//alert(Cn);
	
	var str="";
	if(Cn.length==0){
		flag=false;
		str="must type name";
	}
	else if(tn.length==0){
		flag=false;
		str="Provide Title";
	}
	else if(ins.length==0){
		flag=false;
		str="Provide Institution Info";
	}
	else if(gender.length==0){
		flag=false;
		str="Please Provide your Gender information !";
	}
	else if(medium.length==0){
		flag=false;
		str="Please Provide your medium information !";
	}
	else if(sal.length<3){
		flag=false;
		str="Please Provide Salary !";
	}
	else if(ads.length<5){
		flag=false;
		str="Please Provide your Address !";
	}
	else if(email.indexOf("@")<1){
		flag=false;
		str="invalid email";
	}
	else if(phn.length<11 || phn.length>11){
		flag=false;
		str="Please Provide your Phone Number !";
	}
	else if(info.length<11){
		flag=false;
		str="Please Provide information !";
	}
	
	document.getElementById("msg11").innerHTML=str;
	//alert(flag);
	return flag;
	//if(flag){
  //document.getElementById("frm").submit();
//}
}
</script>