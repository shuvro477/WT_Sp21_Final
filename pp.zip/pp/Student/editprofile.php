<?php include 'Home.php';
	  require 'Controller/ProfileController.php';
	  $id = $_GET["id"];
	  $profile = getProfile($id);
?>
<!--edit profile starts -->
<div class="center">
	<form action="" method="post" class="form-horizontal form-material">
		<div class="form-group">
			<h4 class="text"></h4>
			<input type="hidden" name="id" value="<?php echo $profile["id"];?>">
			<input type="text" name="name" value="<?php echo $profile ["name"];?>" class="form-control">
			<input type="text" name="phone" value="<?php echo $profile ["phone"];?>" class="form-control">
			<input type="text" name="email" value="<?php echo $profile ["email"];?>" class="form-control">
			<input type="text" name="medium" value="<?php echo $profile ["medium"];?>" class="form-control">
			<input type="text" name="class" value="<?php echo $profile ["class"];?>" class="form-control">
			<input type="text" name="gender" value="<?php echo $profile ["gender"];?>" class="form-control">
			
		</div>
		
		<div class="form-group text-center">
			
			<input type="submit" class="btn btn-success" name="edit_profile" value="Update" class="form-control">
		</div>
	</form>
</div>
