<table border="0px" width="100%" cellpadding="0px" cellspacing="0px">
		<tr>
			<td bgcolor="#AFDED3">
			&emsp; &emsp;
				<a href="Profile.php">Profile</a>
			&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				<a href="Home.php">Home</a> 
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				&emsp;&emsp;&emsp;&emsp;
				
				 
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				
				
			</td>
			<td height="20px" bgcolor="grey"align="right">
				<img width="35px" height="38px" src="pictures/logOut.png">
				<a href="../tution_station.php"><font color="white">Log Out</font></a>	
			</td>
		</tr>
</table> <br>

		<Title>
		Change Password
		</title>				
		
		<table border="1px" align="center">
		<tr>
		<td align="center">
			</br>
			
			New Password:
			<input onkeyup="password()" type="password" name="pss" id="pass"> <span id="msg2"></span> <br/> <br/> 
			
			&emsp;
			Confirm Password:
			<input type="password" name="cpss" >&emsp; <br/> <br/>
			
			<p> <input type="submit" onclick="return validate()" name="sbt" value="Confirm" /><br> </p>
			<span id="msg11"></span>
			</td>
			</table>
			

	</pre>
</form>