<?php

$dotPos=strpos($_REQUEST["email"],".");
$atPos=strpos($_REQUEST["email"],"@");

if(strlen($_REQUEST["cName"])==0){
	echo "<p style='color:red'>Provide Valid Name!</p>";
}

else if(strlen($_REQUEST["gender"])==0){
	echo "<p style='color:red'>Select Gender!</p>";
}
else if(strlen($_REQUEST["address"])==0){
	echo "<p style='color:red'>Provide address</p>";
}
else if(strlen($_REQUEST["email"])==0){
	echo "<p style='color:red'>Provide email info</p>";
}

else if(strlen($_POST["phn"])<11){
	echo "<p style='color:red'>Provide Valid Phone Number!</p>";
}

else if($atPos>$dotPos){
	echo "Invalid Email ! Please Give correct email ! ";
}



else{
	
	$sql="insert into av_tution (tittle,name,inst,gender,medium,phone,class,dayCount,sal,loc,email,info) values('".$_REQUEST["title"]."','".$_REQUEST["cName"]."','".$_REQUEST["inst"]."','".$_REQUEST["gender"]."','".$_REQUEST["medium"]."','".$_REQUEST["phn"]."','".$_REQUEST["class"]."','".$_REQUEST["dc"]."','".$_REQUEST["sal"]."','".$_REQUEST["address"]."','".$_REQUEST["email"]."','".$_REQUEST["info"]."')";
	echo $sql;
	$conn = mysqli_connect("localhost", "root", "","Tution");
	$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	$c=mysqli_affected_rows($conn);
		
	echo "</br>Data imported Successfully !";
}

?>
<br>
<br/><a href="PostTution.php">Back</a><br/>