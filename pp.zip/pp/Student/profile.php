<?php
	include("Controller/ProfileController.php");
	$profile = getAllinfo();
?>

<title>Profile </title>


<table border="0px" width="100%" cellpadding="0px" cellspacing="0px">
		<tr>
			<td bgcolor="#AFDED3">
			&emsp; &emsp;
				Student Profile Panel :
			&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				<a href="Home.php">Student Home</a> 
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				&emsp;&emsp;&emsp;&emsp;
				
				<a href="ChangePassword.php">Change Password</a> 
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				
				
				<a href="profile.php">Profile</a>
				
			</td>
			<td height="20px" bgcolor="grey"align="right">
				<img width="35px" height="38px" src="pictures/logOut.png">
				<a href="logout.php"><font color="white">Log Out</font></a>	
			</td>
		</tr>
	</table>
<form action="editprofile.php" align=center method="post" enctype="multipart/form-data" name="mfm"><pre>
	<table class="table table-striped">
		<thead>
			<th> Picture</th>
			<th> Name</th>
			<th> Phone No.</th>
			<th> Email</th>
			<th> Address</th>
			<th> username</th>
			<th> Class</th>
			<th> Medium </th>
			<th> DoB </th>
			<th> Gender </th>
			
		</thead>
		<tbody>
			<?php
				foreach($profile as $p){
					
					echo "<tr>";
						echo "<td> <img src=".$p["url"]." width='200px' height='200px' ></td>";
						echo "<td>".$p["name"]."</td>";
						echo "<td>".$p["phone"]."</td>";
						echo "<td>".$p["email"]."</td>";
						echo "<td>".$p["address"]."</td>";
						echo "<td>".$p["username"]."</td>";
						echo "<td>".$p["class"]."</td>";
						echo "<td>".$p["medium"]."</td>";
						echo "<td>".$p["dob"]."</td>";
						echo "<td>".$p["gender"]."</td>";
						echo '<td><a href="editprofile.php?id='.$p["id"].'" class="btn btn-success">Edit</a></td>';
						//echo '<td><a href="deact.php?id='.$p["id"].'" class="btn btn-danger">Deactivate</a></td>';
					echo "</tr>";
				}
			?>

			
		</tbody>
	</table>	
</form>