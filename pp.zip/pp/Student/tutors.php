<h2>Tutors</h2>

<table border="0px" width="100%" cellpadding="0px" cellspacing="0px">
		<tr>
			<td bgcolor="#AFDED3">
			&emsp; &emsp;
				<a href="Profile.php">Profile</a>
			&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				<a href="Home.php">Home</a> 
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				&emsp;&emsp;&emsp;&emsp;
				
				<a href="ChangePassword.php">Change Password</a> 
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				
				
				
			</td>
			<td height="20px" bgcolor="grey"align="right">
				<img width="35px" height="38px" src="pictures/logOut.png">
				<a href="../tution_station.php"><font color="white">Log Out</font></a>	
			</td>
		</tr>
	</table>


<table>			
		
			<tr border="2px" width="100%" cellpadding="0px" cellspacing="0px" bgcolor="#4BBAD7">
				<td>
					<?php echo "Tutors ID"; echo str_repeat("&nbsp;",6); ?>
				</td>
				<td>
					<?php echo "Tutor Name";echo str_repeat("&nbsp;", 26); ?>
				</td>
				<td>
					<?php echo "Salary"; echo str_repeat("&nbsp;",12); ?>
				</td>
				<td>
					<?php echo "Experience"; echo str_repeat("&nbsp;",12); ?>
				</td>
				</tr>
		 
			
			<tr border="2px" width="100%" cellpadding="0px" cellspacing="0px" bgcolor="#f1f1f1">
				<td>
					<?php echo "1";  ?>
				</td>
				<td>
					<?php echo "Raju"; echo str_repeat("&nbsp;",25); ?>
				</td>
				<td>
					<?php echo "5000";  ?>
				</td>
				<td>
					<?php echo "2 Years"; ?>
				</td>
				<td>
					<a href="nego.php"> Negotiate</a>
				</td>
				<td>
					<a href="Tutor Profile.php"> View</a>
				</td>				
				</tr>
	
	</table>