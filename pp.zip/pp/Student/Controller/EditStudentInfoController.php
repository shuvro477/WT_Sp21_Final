<?php
session_start();
$data=array();
include("Model/lib.php");
//if(isset($_COOKIE["name"]) && $_COOKIE["valid"]=="SET"){
	
	//echo '" . $_SESSION["valid"] . "';
//}
//else{
//	$_SESSION["msg"]="Suspicious login attempt";
//	header("Location:logout.php");
//}
//echo $_SESSION["status"];
?>