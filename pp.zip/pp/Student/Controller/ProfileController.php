<?php
/*
session_start();
$data=array();
include("Model/lib.php");
//include __DIR__ . "/../db/lib.php";
//include $_SERVER['DOCUMENT_ROOT']."/lib/sample.lib.php";
if(isset($_COOKIE["name"]) && $_COOKIE["valid"]=="SET"){
	
	//echo '" . $_SESSION["valid"] . "';
}
else{
	//$_SESSION["msg"]="Suspicious login attempt";
	//header("Location:logout.php");
}
*/
?>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
<?php
	require_once 'Model/db_config.php';

	//declare validation variables
	/*if(isset($_POST["add_category"])){
		//do validation
		insertCategory($_POST["name"]);
	}
	if(isset($_POST["edit_category"])){
		editCategory($_POST["id"],$_POST["name"]);
	}
	function insertCategory($name){
		$query = "insert into categories values(NULL,'$name')";
		execute($query);
		header("Location: allcategories.php");
	}
	*/
	if(isset($_POST["edit_profile"])){
		editProfile($_POST["id"],$_POST["name"],$_POST["phone"],$_POST["email"],$_POST["medium"],$_POST["class"],$_POST["gender"]);
	}
	

	function editProfile($id,$name,$phone,$email,$medium,$class,$gender){
		$query = "update student set name='$name', email='$email', medium='$medium',phone='$phone',class='$class',gender='$gender' where id=$id";
		execute($query);
		header("Location: profile.php");
	}
	function getProfile($id){
		$query = "select * from student where id=$id";
		$result = get($query);
		if(count($result) > 0){
			return $result[0];
		}
		return false;
	}
	function getAllinfo(){
		$query = "select * from student";
		$result = get($query);
		return $result;
	}
?>