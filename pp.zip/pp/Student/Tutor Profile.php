<title>Tutor Profile </title>


<table border="0px" width="100%" cellpadding="0px" cellspacing="0px">
		<tr>
			<td bgcolor="#AFDED3">
			&emsp; &emsp;
				<a href="Profile.php">Profile</a> 
			&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				<a href="Home.php">Home</a> 
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				&emsp;&emsp;&emsp;&emsp;
				
				<a href="ChangePassword.php">Change Password</a> 
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				
				
				
			</td>
			<td height="20px" bgcolor="grey"align="right">
				<img width="35px" height="38px" src="pictures/logOut.png">
				<a href="../tution_station.php"><font color="white">Log Out</font></a>	
			</td>
		</tr>
	</table>
	<a href="tutors.php"> Back</a>
<form action="upload.php" align=center method="post" enctype="multipart/form-data" name="mfm"><pre>

	<table border="0px" width="80%" cellpadding="0px" cellspacing="0px" bgcolor="#f1f1f1">
		<tr>
			<td><b> <img src="" width="200px" height="200px" > </b></font></td>
			<td>
				<table border="1px">
					<tr>
						<td border="2px">Name</td> <td border="2px">Phone no.</td> <td border="2px">Email</td> <td border="2px">Address</td> <td border="2px">Experience</td>
					</tr>
					<tr border="1px">
						<td> <?php echo "Raju"; ?> </td> <td> <?php echo "01XXXXXXXXX"; ?> </td> 
						<td> <?php echo "raju@gmail.com"; ?> </td> <td> <?php echo "Dhaka, Bangladesh"; ?> </td>
						<td> <?php echo "2 Years" ?> </td>
						<td> <a href="bookTutor.php"> Hire </a>
					</td>
						
					</tr>
				</table>					
		
	</table>
</form>