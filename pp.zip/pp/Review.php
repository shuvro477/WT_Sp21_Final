<html> 
<head>
<title> check review  </title> 
<style>
.myDiv {
  border: 5px outset black;
  background-color: red;
  text-align: center;
}
</style>
</head>
<body>

<div class="myDiv">
  <h1>  NO REVIEWS YET <br> </h1>
  <h2>Stay Connect with Tuition Station </h2>
  <h3> Thank you :) </h3>
</div>

</body>
</html>