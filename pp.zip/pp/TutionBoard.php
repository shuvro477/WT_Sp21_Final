<html>
 <head><title>Tuition Board</title>
    <style>
	    #header{
			height:25px;
			background-color:black;
			position:fixed;
			width:100%;
			top:0;
			left:0;
			color:white
		}
		
	    #p1div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p2div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p3div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p4div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p5div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#footer{
			height:15px;
			background-color:black;
			position:fixed;
			width:100%;
			bottom:0;
			left:0;
		}
		
	</style>
 </head>
     <body style="background-color:rgb(151, 117, 250);">
    
    <div id="header"></div><br>
    <H1 style="text-align:center;"> Tuition Board </H1>
	<h2 style="margin-left:35px;margin-right:93%;color:pink;background-color:RGB(80, 159, 0)"><b><a href="TutorHome.php">Home</a></b></h3>
	<div id="p1div" style="background-color: white;">
        <b>Need Bangla Medium Tutor for Class 2 Student - 5Days/Week</b><br>
        <p>ID:1001   |   Mar 12,2021 </p>
        <ul type="disc">
            <li><b>Location:</b> Mirpur 13, Dhaka </li><br>                                
	        <li><b>Subject:</b> All</li><br>
	        <li><b>Salary:</b> 3000BDT<br>
		     
            <p style="text-align:right;"><a target="_blank" href="View Details 1.php">View Details</a></p>
		
	</div><br>
	
	<div id="p2div" style="background-color: white;">
        <b>Need English Medium Tutor for Standard 5 Student - 4Days/Week</b><br>
        <p>ID:1002  |   Feb 27,2021 </p>
        <ul type="disc">
            <li><b>Location:</b> Mohammadpur 15, Dhaka </li><br>                                
	        <li><b>Subject:</b> All</li><br>
	        <li><b>Salary:</b> 5000BDT<br>
		
		    <p style="text-align:right;"><a target="_blank" href="View Details 2.php">View Details</a></p>
	</div><br>
	
	<div id="p3div" style="background-color: white;">
        <b>Need Professional Skill Development Tutor for Computer Programming Student - 3Days/Week</b><br>
        <p>ID:1003   |   Feb 15,2021 </p>
        <ul type="disc">
            <li><b>Location:</b> Khulshi 11, Chittagong </li><br>                                
	        <li><b>Subject:</b> C, C++, Java</li><br>
	        <li><b>Salary:</b> 7000BDT<br>
			
			 <p style="text-align:right;"><a target="_blank" href="View Details 3.php">View Details</a></p>
	</div><br>
	
	<div id="p4div" style="background-color: white;">
        <b>Need Religious Studies Tutor for Islamic Studies Student - 3Days/Week</b><br>
        <p>ID:1004   |   Jan 12,2021 </p>
        <ul type="disc">
            <li><b>Location:</b> Shahjalal Upashahar G Block, Sylhet </li><br>                                
	        <li><b>Subject:</b> Quran for Beginner</li><br>
	        <li><b>Salary:</b> 3000BDT<br>
			
			<p style="text-align:right;"><a target="_blank" href="View Details 4.php">View Details</a></p>
	</div><br>
	
	<div id="p5div" style="background-color: white;">
        <b>Need Math Tutor for Class 9 Student - 3Days/Week</b><br>
        <p>ID:1005   |   Jan 04,2021 </p>
        <ul type="disc">
            <li><b>Location:</b> Esa Khan Road, Narayanganj </li><br>                                
	        <li><b>Subject:</b> Math</li><br>
	        <li><b>Salary:</b> 4000BDT<br>
			
			<p style="text-align:right;"><a target="_blank" href="View Details 5.php">View Details</a></p>
	</div><br>
	<div id="footer"></div>
 </body>
</html>