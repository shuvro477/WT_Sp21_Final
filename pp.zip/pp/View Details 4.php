<html>
 <head><title>View Details</title>
    <style>
	    #header{
			height:25px;
			background-color:black;
			position:fixed;
			width:100%;
			top:0;
			left:0;
			color:white
		}
		
	    #p1div{
			border:1px solid black;
			margin:auto;
			width:50%;
			border-radius:10px;
			padding-left:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		
	</style>
 </head>
 <body style="background-color:rgb(151, 117, 250);">
    <div id="header"></div><br>
    <H1 style="text-align:center;"> Need Religious Studies Tutor for Islamic Studies Student - 3Days/Week </H1>
	<p style="text-align:center;"><b>ID:1004</b></p><br>
	<div id="p1div" style="background-color: white;">
        <p>Posted Date: Jan 12,2021 </p>
        <ul type="square">                               
	        <li><b>Subjects:</b><br> Quran for Beginner</li><br>
			<li><b>No of Student: </b><br> 2</li><br>
			<li><b>Student Gender: </b><br> Male</li><br>
			<li><b>Preferred Tutor: </b><br> Male</li><br>
			<li><b>Tutoring Days: </b><br> 3Days/Week</li><br>
	        <li><b>Salary: </b><br> 3000BDT</li><br>
			<li><b>Tutoring Time: </b><br> 5:00pM</li><br>
			<li><b>Location: </b><br> Shahjalal Upashahar G Block, Sylhet </li><br> 
			<li><b>Other Requirements: </b><br> Interested tutors are requested to contact.</li><br>
		<table><tr>
		     <td colspan="2" align="right"><input type="submit" value="Apply" name="Apply"></td>
		</tr></table>
	</div><br>
  
 </body>
</html>