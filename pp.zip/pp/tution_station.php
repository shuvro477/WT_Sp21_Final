<?php
	session_destroy();
?>
<html>
	<head>
	    <title>Tution Station</title>
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		
	</head>
	<body>
	    
		
		<div class="menu-bar">
		
				<a href="tution_station.php"><img src="logo.png" class="logo"></a>
			
			
				<ul>
			
					<li class="active"><a href="login.php"><i class="fa fa-sign-in"></i>Login</a></li>
					
					<li><a href="#"><i class="fa fa-clone"></i>Find A Tutor</a>
						<div class="sub-menu-1">
							<!--<ul>
									<li><a href="#">Search for Tutors</a></li>
									<li><a href="#">Rrequest A Tutor</a></li>
									<li><a href="#">Online Tutoring</a></li>
							 </ul>	
						 </div>-->
					</li>					 
					<li><a href="#"><i class="fa fa-clone"></i>How It Works</a>
						<!--<div class="sub-menu-1">
							<ul>
									<li><a href="#">For Student</a></li>
									<li><a href="#">For Higher Ed</a></li>
									<li><a href="#">What Customer Say</a></li>
							 </ul>	
						 </div>-->
					</li>
					<li><a href="#"><i class="fa fa-user"></i>About Us</a>
						<div class="sub-menu-1">
							<ul>
									<li><a href="#">About Us</a></li>
									<li><a href="#">Our Team</a></li>
									<li><a href="#"></i>Contact Us</a></li>
							 </ul>	
						 </div>
					</li>
					
				</ul>
			
		</div>
		<div class="back-img">
			
			<div class="left">
			<button style="" onclick="window.location.href='TopList/TutorList.php';">Top Tutor List</button>
			<h1 class="Text1">Welcome To Tution Station</h1>
			<h2 class="Text2">Find Your Best Tutor/Tution</h2>
			<div class="buttons">
			<p><br></p>
			<button onclick="window.location.href='login.php';">Log in</button>
			<button class="btn2" onclick="window.location.href='signup.php';">Sign Up</button>
		    </div>
		
	</body>
</html>