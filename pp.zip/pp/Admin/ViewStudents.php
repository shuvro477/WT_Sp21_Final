<html>
 <head><title>Tuition Station</title>
    <style>
	    #header{
			height:25px;
			background-color:black;
			position:fixed;
			width:100%;
			top:0;
			left:0;
			color:white
		}
		
	    #p1div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p2div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p3div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p4div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p5div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#footer{
			height:15px;
			background-color:black;
			position:fixed;
			width:100%;
			bottom:0;
			left:0;
		}
		
	</style>
 </head>
     <body style="background-color:rgb(151, 117, 250);">
    
    <div id="header"></div><br>
    <H1 style="text-align:center;"> Admin Profile </H1>
	<h2 style="margin-left:35px;margin-right:93%;color:pink;background-color:RGB(80, 159, 0)"><b><a href="AdminHome.php">Home</a></b></h3>
	<div id="p1div" style="background-color: white;">
        <p></p><br>
        <table border="1" style="border-collapse:collapse;">
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Username</th>
				<th>Institution</th>
				<th>Date of Birth</th>
				<th>Gender</th>
				<th>Class</th>
				<th>Medium</th>
				<th colspan="2">Operation</th>
			</tr>
			<tr>
				<td>1</td>
				<td>Saiful Islam</td>
				<td>saiful</td>
				<td>CBA School</td>
				<td>10/06/2002</td>
				<td>Male</td>
				<td>Class 10</td>
				<td>Bangla</td>
				<td><a href='EditStudent.php'> Edit </a></td>
		        <td><a href=''> Delete </a></td>
			</tr>
			<tr>
				<td>1</td>
				<td>Asif Sahrir</td>
				<td>asif</td>
				<td>AAMC School</td>
				<td>23/08/2002</td>
				<td>Male</td>
				<td>Class 11</td>
				<td>Bangla</td>
				<td><a href='EditStudent.php'> Edit </a></td>
		        <td><a href=''> Delete </a></td>
			</tr>
			<tr>
				<td>1</td>
				<td>Eyafin Tafia</td>
				<td>tafia</td>
				<td>ABC School</td>
				<td>14/03/2001</td>
				<td>Female</td>
				<td>Class 11</td>
				<td>English</td>
				<td><a href='EditStudent.php'> Edit </a></td>
		        <td><a href=''> Delete </a></td>
			</tr>
		
		
	</div><br> 
	
	
	<div id="footer"></div>
 </body>
</html>