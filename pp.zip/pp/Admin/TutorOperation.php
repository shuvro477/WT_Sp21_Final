<html>
 <head><title>Tuition Station</title>
    <style>
	    #header{
			height:25px;
			background-color:black;
			position:fixed;
			width:100%;
			top:0;
			left:0;
			color:white
		}
		
	    #p1div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p2div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p3div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p4div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#p5div{
			border:1px solid black;
			margin:auto;
			width:95%;
			border-radius:10px;
			padding-left:15px;
			padding-right:15px;
			padding-top:15px;
			padding-bottom:15px;
		}
		
		#footer{
			height:15px;
			background-color:black;
			position:fixed;
			width:100%;
			bottom:0;
			left:0;
		}
		
	</style>
 </head>
     <body style="background-color:rgb(151, 117, 250);">
    
    <div id="header"></div><br>
    <H1 style="text-align:center;"> Admin Operations </H1>
	<h2 style="margin-left:35px;margin-right:93%;color:pink;background-color:RGB(80, 159, 0)"><b><a href="AdminHome.php">Home</a></b></h3>
	<div id="p1div" style="background-color: white;">
        <p></p><br>
        
		<p><b><a href="AddTutor.php">Add Tutor</a></b></p>
		<p><b><a href="SearchTutors.php">Search Tutor</a></b></p>
		<p><b><a href="ViewTutors.php">View Tutors</a></b></p>
	    
		     
            
		
	</div><br> 
	
	
	<div id="footer"></div>
 </body>
</html>